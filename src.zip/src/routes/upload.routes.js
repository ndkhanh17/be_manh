const express = require("express")
const router = express.Router()
const UploadController = require("../controllers/upload.controller")
const authMiddleware = require("../middlewares/auth.middleware")
const multer = require("multer")
const path = require("path")

// Cấu hình multer để lưu trữ file
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/")
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    const ext = path.extname(file.originalname)
    cb(null, file.fieldname + "-" + uniqueSuffix + ext)
  },
})

// Lọc file - chỉ chấp nhận ảnh
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true)
  } else {
    cb(new Error("Chỉ chấp nhận file ảnh!"), false)
  }
}

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // giới hạn 5MB
  },
  fileFilter: fileFilter,
})

// Route upload ảnh (yêu cầu đăng nhập)
router.post("/image", authMiddleware.authenticate, upload.single("image"), UploadController.uploadImage)

// Route upload nhiều ảnh (yêu cầu đăng nhập)
router.post(
  "/images",
  authMiddleware.authenticate,
  upload.array("images", 5), // tối đa 5 ảnh
  UploadController.uploadMultipleImages,
)

// Route xóa ảnh (yêu cầu quyền admin)
router.delete(
  "/image/:filename",
  authMiddleware.authenticate,
  authMiddleware.authorize("admin"),
  UploadController.deleteImage,
)

module.exports = router
